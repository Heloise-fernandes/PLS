
#ifndef RLE_H
#define RLE_H


#include <stdio.h>
#include <stdlib.h>
#include "Lecture_Ecriture_B.h"

void RLE(FILE* fichier_src,FILE* fichier_dest);

void unRLE(FILE* fichier_src,FILE* fichier_dest);
#endif
